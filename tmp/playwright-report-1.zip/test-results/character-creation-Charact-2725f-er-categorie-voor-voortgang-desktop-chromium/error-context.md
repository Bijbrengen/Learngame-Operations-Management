# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: character-creation.spec.js >> Character Creation & Gedragsscan Wizard >> wizard opent introductie en vereist 20 punten per categorie voor voortgang
- Location: tests/visual/character-creation.spec.js:11:3

# Error details

```
Error: expect(locator).toBeVisible() failed

Locator: locator('[data-action="begin-scans"]')
Expected: visible
Timeout: 10000ms
Error: element(s) not found

Call log:
  - Expect "toBeVisible" with timeout 10000ms
  - waiting for locator('[data-action="begin-scans"]')

```

```yaml
- region:
  - text: Accountprofiel
  - heading "Profielcontrole is niet gelukt" [level=2]
  - paragraph: De profielservice antwoordde met status 404.
  - button "Opnieuw controleren"
```

# Test source

```ts
  1  | const { test, expect } = require("@playwright/test");
  2  | 
  3  | test.describe("Character Creation & Gedragsscan Wizard", () => {
  4  |   test.beforeEach(async ({ page }) => {
  5  |     await page.route("**/accounts.google.com/**", route => route.fulfill({ status: 200, contentType: "application/javascript", body: "" }));
  6  |     await page.route("**/v1/player/behavior-profile**", route => {
  7  |       route.fulfill({ status: 404, contentType: "application/json", body: JSON.stringify({ exists: false }) });
  8  |     });
  9  |   });
  10 | 
  11 |   test("wizard opent introductie en vereist 20 punten per categorie voor voortgang", async ({ page }) => {
  12 |     await page.goto("/");
  13 |     await page.waitForFunction(() => window.BehaviorCharacterCreation);
  14 | 
  15 |     await page.evaluate(() => {
  16 |       document.body.className = "";
  17 |       const authGate = document.getElementById("leerpretAuthGate");
  18 |       if (authGate) authGate.hidden = true;
  19 | 
  20 |       const charGate = document.getElementById("characterCreationGate");
  21 |       if (charGate) charGate.hidden = false;
  22 | 
  23 |       window.BehaviorCharacterCreation.start({ authenticated: true });
  24 |     });
  25 | 
  26 |     const beginBtn = page.locator('[data-action="begin-scans"]');
> 27 |     await expect(beginBtn).toBeVisible({ timeout: 10000 });
     |                            ^ Error: expect(locator).toBeVisible() failed
  28 |     await beginBtn.click({ force: true });
  29 | 
  30 |     await expect(page.getByRole("heading", { name: "Baseline Attribute Allocation" })).toBeVisible();
  31 | 
  32 |     const nextBtn = page.locator('[data-action="next"]');
  33 |     await expect(nextBtn).toBeDisabled();
  34 | 
  35 |     const inputs = page.locator(".trait-value-input");
  36 |     await expect(inputs).toHaveCount(4);
  37 |     for (let i = 0; i < 4; i++) {
  38 |       await inputs.nth(i).fill("5");
  39 |       await inputs.nth(i).dispatchEvent("change");
  40 |     }
  41 | 
  42 |     await expect(nextBtn).toBeEnabled();
  43 |     await expect(page.locator(".point-budget")).toContainText("0");
  44 | 
  45 |     await nextBtn.click({ force: true });
  46 |     await expect(page.locator(".category-heading")).toContainText("Attribuutnode 2 van 10");
  47 |   });
  48 | 
  49 |   test("kwaliteitscontrole signaleert te uniforme scans", async ({ page }) => {
  50 |     await page.goto("/");
  51 |     await page.waitForFunction(() => window.BehaviorQuality);
  52 | 
  53 |     const result = await page.evaluate(() => {
  54 |       const flatScan = Array(10).fill([5, 5, 5, 5]);
  55 |       return window.BehaviorQuality.assessQuality({
  56 |         basic_style: flatScan,
  57 |         response_style: flatScan
  58 |       });
  59 |     });
  60 | 
  61 |     expect(result).not.toBeNull();
  62 |     expect(result.pass).toBe(false);
  63 |     expect(result.reasons.length).toBeGreaterThan(0);
  64 |   });
  65 | });
  66 | 
```