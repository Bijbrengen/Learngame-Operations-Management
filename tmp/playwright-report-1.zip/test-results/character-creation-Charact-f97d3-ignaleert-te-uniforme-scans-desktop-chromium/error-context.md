# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: character-creation.spec.js >> Character Creation & Gedragsscan Wizard >> kwaliteitscontrole signaleert te uniforme scans
- Location: tests/visual/character-creation.spec.js:49:3

# Error details

```
Test timeout of 30000ms exceeded.
```

```
Error: page.waitForFunction: Test timeout of 30000ms exceeded.
```

# Page snapshot

```yaml
- generic [active] [ref=e1]:
  - region [ref=e2]:
    - generic [ref=e3]:
      - generic [ref=e4]: LP
      - generic [ref=e5]:
        - paragraph [ref=e6]: Leerpret-account
        - heading "Veilig en pseudoniem aanmelden" [level=2] [ref=e7]
        - paragraph [ref=e8]: Meld je in deze standalone game pseudoniem aan met je Google-account. Leerpret vraagt Google alleen om een vaste accountcode, niet om je naam, e-mailadres of profielfoto. Open je de game vanuit Leerpret terwijl je daar al bent ingelogd, dan wordt die aanmelding automatisch overgenomen.
      - status [ref=e9]: De Leerpret-service is niet bereikbaar. Start de backend en probeer opnieuw.
      - generic "Aanmelden met Google" [ref=e10]
      - generic [ref=e11]: De accountcode wordt direct met een geheime sleutel gepseudonimiseerd. De beperkte, aflopende HttpOnly-sessie geeft geen toegang tot de Leerpret-engine of beheerrollen.
  - generic:
    - banner:
      - button "Tutorial beëindigen" [ref=e12] [cursor=pointer]: ×
    - main "Beheerdersdashboard":
      - region "Bouw de klantbestelling":
        - generic:
          - generic:
            - paragraph: Interactieve productie
            - heading "Bouw de klantbestelling" [level=2]
          - generic: 6×6 studs
        - generic:
          - paragraph: "De LeerpretSDK lego-logica kon niet worden geladen. Controleer of de backend bereikbaar is (of stel window.LEERPRET_SDK_BASE in). Geprobeerde URL: http://127.0.0.1:47111/api/sdk/lego-builder/logic.js (pagina: http://127.0.0.1:47113)."
```

# Test source

```ts
  1  | const { test, expect } = require("@playwright/test");
  2  | 
  3  | test.describe("Character Creation & Gedragsscan Wizard", () => {
  4  |   test.beforeEach(async ({ page }) => {
  5  |     await page.route("**/accounts.google.com/**", route => route.fulfill({ status: 200, contentType: "application/javascript", body: "" }));
  6  |     await page.route("**/v1/player/behavior-profile**", route => {
  7  |       route.fulfill({ status: 404, contentType: "application/json", body: JSON.stringify({ exists: false }) });
  8  |     });
  9  |   });
  10 | 
  11 |   test("wizard opent introductie en vereist 20 punten per categorie voor voortgang", async ({ page }) => {
  12 |     await page.goto("/");
  13 |     await page.waitForFunction(() => window.BehaviorCharacterCreation);
  14 | 
  15 |     await page.evaluate(() => {
  16 |       document.body.className = "";
  17 |       const authGate = document.getElementById("leerpretAuthGate");
  18 |       if (authGate) authGate.hidden = true;
  19 | 
  20 |       const charGate = document.getElementById("characterCreationGate");
  21 |       if (charGate) charGate.hidden = false;
  22 | 
  23 |       window.BehaviorCharacterCreation.start({ authenticated: true });
  24 |     });
  25 | 
  26 |     const beginBtn = page.locator('[data-action="begin-scans"]');
  27 |     await expect(beginBtn).toBeVisible({ timeout: 10000 });
  28 |     await beginBtn.click({ force: true });
  29 | 
  30 |     await expect(page.getByRole("heading", { name: "Baseline Attribute Allocation" })).toBeVisible();
  31 | 
  32 |     const nextBtn = page.locator('[data-action="next"]');
  33 |     await expect(nextBtn).toBeDisabled();
  34 | 
  35 |     const inputs = page.locator(".trait-value-input");
  36 |     await expect(inputs).toHaveCount(4);
  37 |     for (let i = 0; i < 4; i++) {
  38 |       await inputs.nth(i).fill("5");
  39 |       await inputs.nth(i).dispatchEvent("change");
  40 |     }
  41 | 
  42 |     await expect(nextBtn).toBeEnabled();
  43 |     await expect(page.locator(".point-budget")).toContainText("0");
  44 | 
  45 |     await nextBtn.click({ force: true });
  46 |     await expect(page.locator(".category-heading")).toContainText("Attribuutnode 2 van 10");
  47 |   });
  48 | 
  49 |   test("kwaliteitscontrole signaleert te uniforme scans", async ({ page }) => {
  50 |     await page.goto("/");
> 51 |     await page.waitForFunction(() => window.BehaviorQuality);
     |                ^ Error: page.waitForFunction: Test timeout of 30000ms exceeded.
  52 | 
  53 |     const result = await page.evaluate(() => {
  54 |       const flatScan = Array(10).fill([5, 5, 5, 5]);
  55 |       return window.BehaviorQuality.assessQuality({
  56 |         basic_style: flatScan,
  57 |         response_style: flatScan
  58 |       });
  59 |     });
  60 | 
  61 |     expect(result).not.toBeNull();
  62 |     expect(result.pass).toBe(false);
  63 |     expect(result.reasons.length).toBeGreaterThan(0);
  64 |   });
  65 | });
  66 | 
```